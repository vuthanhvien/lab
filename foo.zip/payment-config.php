<?php

$vnp_TmnCode = "VE7Y8HTR";
$vnp_HashSecret = "4Z9QL1HG3TM2AFVP5DF3S2UNBQ288308";
$vnp_Url = "http://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
$vnp_Returnurl = "http://dev.chienluocso.vn/payment-confirm.php";